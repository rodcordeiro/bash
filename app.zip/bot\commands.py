
class Commands:
    def __init__(self):
        self.__init__ = self