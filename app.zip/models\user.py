from db import Database

db = Database()

class User:
    def __init__(self, guild_id,user):
        self.id = user.id
        self.name = user.name
        self.nick = user.nick
        self.isBot = user.bot
        if user.bot == False:
            userData = db.has_user(guild_id,user)
            if userData:
                self.xp = userData['XP']
                self.level = self.xp
